# -*- coding: utf-8 -*-
"""
# ===================================
# This python routine was developed as part of a SHIELD NASA DRIVE Science Center research project (NASA grant 18-DRIVE18_2-0029, Our Heliospheric Shield, 80NSSC22M0164).
# This pre-release version was provided for the SHIELD Summer School 2025 as part of an ENA Activity.
# This version is not maintained. An updated version is available on Github (https://github.com/jgazer/mollpy-skymaps).
#
# Author: Jonathan Gasser, Southwest Research Institute, San Antonio, TX, USA;
# Contact: jonathan.gasser at swri.org
# ===================================

Script to run the rotated maps plotting routine.
For the use of scientific color palettes developed by Fabio Crameri (doi: 10.5281/zenodo.1243862):
    1 in your command line, enter:
        pip install cmcrameri
    2 uncomment the 'import' statement below.
    3 see also:
        https://pypi.org/project/cmcrameri/
        https://www.fabiocrameri.ch/colourmaps/
The 'Batlow' colorbar is used as an example; uncomment the 'cmap' keyword assignment.

Version:  v1.2 (2024-10-22)
Created on Wed Jun  5 09:23:30 2024

@author: jgazer
"""

import numpy as np
import matplotlib.pyplot as plt
import loadibex as lix
import map_rotated
# import cmcrameri.cm as cmc # used for 'batlow' colorscheme

#==============================
alf = 35  # angle between old pole and new pole
phi = -30  # longitude where the new pole is
th = 0 # end rotation towards positive azimuth
#==============================

lons, lats, data = lix.load_ibexfile_std(year=2009)
data[ np.where(data<=0) ] =np.nan

fig, ax = map_rotated.plot_rotated_map(lons, lats, data, alf=alf, phi=phi, th=th,
                                       title='IBEX-Hi 1.11keV (2009)', 
                                       #cmap=cmc.batlow, grid_color= 'k',
                                       # cbar_kwargs={'location':'right','aspect':28, 'fraction':0.7},
                                       # center_meridian=True,
                                       tick_font= 30,
                                       orientation_kw= 'nose' )

plt.plot(0,0,'ok')
plt.text(.03,.02,'Nose', fontsize= 30)

plt.show()
